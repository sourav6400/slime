@extends('layouts.app')

@section('content')
<!-- BEGIN: Content-->
<div class="content-overlay"></div>
<div class="header-navbar-shadow"></div>
<div class="content-wrapper container-xxl p-0">
    <div class="content-body">
        <!-- Select2 Start  -->
        <section id="multiple-column-form">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-1">Add New Campaign</h4>
                            <div class="div d-none">
                                <a href="#" class="btn btn-primary mb-1">Going to managment view</a>
                                <a href="#" class="btn btn-primary mb-1">Generate Quoatation</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <form class="form">
                                <div class="row">
                                    <div class="col-md-8 col-12">
                                        <div class="mb-1">
                                            <label class="form-label" for="campaignname">Campaign Name</label>
                                            <input type="text" id="campaignname" class="form-control"
                                                placeholder="Campaign Name" name="campaignname" />
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-12">
                                        <div class="mb-1">
                                            <label class="form-label" for="strdate">Starting Date:</label>
                                            <input type="date" name="strdate" id="strdate" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-12">
                                        <div class="mb-1">
                                            <label class="form-label" for="enddate">Ending Date:</label>
                                            <input type="date" name="enddate" id="enddate" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-12 mb-1">
                                        <label class="form-label" for="select5-basic">Select A Client</label>
                                        <select class="select2 form-select" id="select5-basic">
                                            <option value="chose">Richard - example@gmail.com - @some</span></option>
                                            <option value="Facebook">James - example@gmail.com - @some</option>
                                            <option value="Twitter">Robert - example@gmail.com - @some</option>
                                            <option value="TTiktokK">Michael - example@gmail.com - @some</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label" for="select9-multiple">Select A Region</label>
                                        <select class="select2 form-select" id="select9-multiple" multiple>
                                            <optgroup label="Select Upto all">
                                                <option value="chose">Dhaka</option>
                                                <option value="Facebook">Cumilla</option>
                                                <option value="Twitter">Barisal</option>
                                                <option value="TTiktokK">Thakurgaon</option>
                                                <option value="Likee">Rajshahi</option>
                                                <option value="YouTube">YouTube</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-1">
                                        <label for="budget" class="form-label">Define Your Budget</label>
                                        <input type="text" name="budget" id="budget" class="form-control"
                                            placeholder="Define Your Budget">
                                    </div>
                                    <div class="col-md-4 mb-1">
                                        <label for="kpi" class="form-label">Define Your KPI :</label>
                                        <input type="text" name="kpi" id="kpi" class="form-control"
                                            placeholder="Define Your Kpi :">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-1">
                                            <label for="asset" class="form-label">Asset</label>
                                            <input type="text" name="asset" id="asset" class="form-control"
                                                placeholder="Google Doc Link">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-1">
                                            <label for="brief" class="form-label">Client Brief</label>
                                            <input type="text" name="brief" id="brief" class="form-control"
                                                placeholder="Google Doc Link">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mb-1">
                                            <label class="form-label" for="exampleFormControlTextarea1">Client Brief
                                                Description</label>
                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                                placeholder="Type here"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" id="advanced-search-datatable">
                                    <div class="col-12 col-lg-9">
                                        <div class="card">
                                            <div class="card-header border-bottom d-flex justify-content-between">
                                                <h4 class="card-title">Select Influencer</h4>
                                            </div>
                                            <!--Search Form -->
                                            <div class="card-body mt-2">
                                                <div class="dt_adv_search" method="POST">
                                                    <div class="row g-1 mb-md-1">
                                                        <div class="col-md-4">
                                                            <label class="form-label" for="nm">Name:</label>
                                                            <input type="text" id="nm"
                                                                class="form-control dt-input dt-full-name"
                                                                data-column="1" placeholder="Alaric Beslier"
                                                                data-column-index="0" />
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label" for="em/tg">Email /
                                                                Telegram</label>
                                                            <input type="text" id="em/tg" class="form-control dt-input"
                                                                data-column="2" placeholder="Email or Telegram"
                                                                data-column-index="1" />
                                                        </div>
                                                        <div class="col-md-4 mb-1">
                                                            <label class="form-label" for="select3-basic">Region</label>
                                                            <select class="select2 form-select" id="select3-basic">
                                                                <option value="chose">Dhaka</option>
                                                                <option value="Facebook">Cumilla</option>
                                                                <option value="Twitter">Barisal</option>
                                                                <option value="TTiktokK">Thakurgaon</option>
                                                                <option value="Likee">Rajshahi</option>
                                                                <option value="YouTube">YouTube</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row g-1">
                                                        <div class="col-md-4">
                                                            <label class="form-label"
                                                                for="select0-multiple">Social</label>
                                                            <select class="select2 form-select" id="select0-multiple"
                                                                multiple>
                                                                <optgroup label="Select Upto all">
                                                                    <option value="chose">Facebook</option>
                                                                    <option value="Facebook">Tiktok</option>
                                                                    <option value="Twitter">Twitter</option>
                                                                    <option value="TTiktokK">Telegram</option>
                                                                    <option value="Likee">YouTube</option>
                                                                    <option value="YouTube">Instagram</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label"
                                                                for="select5-multiple">Tags</label>
                                                            <select class="select2 form-select" id="select5-multiple"
                                                                multiple>
                                                                <optgroup label="Select Upto all">
                                                                    <option value="Facebook">Content Creator</option>
                                                                    <option value="Twitter">Artist</option>
                                                                    <option value="Vibas">Vibas</option>
                                                                    <option value="Collector">Collector</option>
                                                                    <option value="NFT">NFT</option>
                                                                    <option value="NFT Collector">NFT Collector</option>
                                                                    <option value="Host">Host</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label class="form-label"
                                                                for="select6-multiple">Content</label>
                                                            <select class="select2 form-select" id="select6-multiple"
                                                                multiple>
                                                                <optgroup label="Select Upto all">
                                                                    <option value="Tweet">Tweet</option>
                                                                    <option value="Thread">Thread</option>
                                                                    <option value="RT">RT</option>
                                                                    <option value="Artist">Artist</option>
                                                                    <option value="Spece Host">Spece Host</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="my-0" />
                                            <div class="card-datatable table-responsive">
                                                <table class="dt-advanced-search table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>
                                                                <div class="form-check">
                                                                    <input type="checkbox" class="form-check-input"
                                                                        name="" id="select-all">
                                                                </div>
                                                            </th>
                                                            <th>Name</th>
                                                            <th>Region</th>
                                                            <th>Tags</th>
                                                            <th>Social</th>
                                                            <th>Content</th>
                                                            <th>Total Flowers</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <div class="form-check">
                                                                    <input data-bs-toggle="modal"
                                                                        data-bs-target="#addPermissionModal"
                                                                        type="checkbox" name="" id="check1"
                                                                        class="form-check-input">
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <a href="account.html">
                                                                    <img src="app-assets/images/portrait/small/avatar-s-3.jpg"
                                                                        class="me-75" height="50" width="50"
                                                                        alt="Angular" />
                                                                    <span class="fw-bold text-light">Blake Jhon</span>
                                                                </a>
                                                            </td>
                                                            <td>Dhaka</td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Content
                                                                    Creator</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Artist</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Vibas</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Collector</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">NFT</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">NFT
                                                                    Collector</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Host</span>
                                                            </td>
                                                            <td class="">
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="facebook"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="youtube"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="twitter"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="linkedin"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="instagram"></i></a>
                                                            </td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">TP-
                                                                    $25</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">FP-
                                                                    $10</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RT-
                                                                    $55</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">L-
                                                                    $35</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RV-
                                                                    $20</span>
                                                            </td>
                                                            <td>
                                                                <h5>25000</h5>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <div class="form-check">
                                                                    <input data-bs-toggle="modal"
                                                                        data-bs-target="#addPermissionModal"
                                                                        type="checkbox" name="" id="check1"
                                                                        class="form-check-input">
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <a href="account.html">
                                                                    <img src="app-assets/images/portrait/small/avatar-s-7.jpg"
                                                                        class="me-75" height="50" width="50"
                                                                        alt="Angular" />
                                                                    <span class="fw-bold text-light">Smith Roy</span>
                                                                </a>
                                                            </td>
                                                            <td>Dhaka</td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Content
                                                                    Creator</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Artist</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Vibas</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Collector</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">NFT</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">NFT
                                                                    Collector</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">Host</span>
                                                            </td>
                                                            <td class="">
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="facebook"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="youtube"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="twitter"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="linkedin"></i></a>
                                                                <a class="badge rounded-pill badge-light-success link-bottom"
                                                                    href="#"><i data-feather="instagram"></i></a>
                                                            </td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">TP-
                                                                    $25</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">FP-
                                                                    $10</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RT-
                                                                    $55</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">L-
                                                                    $35</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RV-
                                                                    $20</span>
                                                            </td>
                                                            <td>
                                                                <h5>25000</h5>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>
                                                                <div class="form-check">
                                                                    <input type="checkbox" name="" id="check1"
                                                                        class="form-check-input">
                                                                </div>
                                                            </th>
                                                            <th>Name</th>
                                                            <th>Region</th>
                                                            <th>Tags</th>
                                                            <th>Social</th>
                                                            <th>Content</th>
                                                            <th>Total Flowers</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                                <div class="col-12 my-2">
                                                    <a href="approve.html" class="btn btn-primary mb-1 csm-25">Create &
                                                        Sent to Client</a>
                                                    <a href="#" class="btn btn-primary ml-2 top-12">Create draft</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-3 mt-lg-5 pt-lg-1">
                                        <div class="card">
                                            <div class="card-datatable table-responsive">
                                                <table class="dt-advanced-search table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Content</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <a href="account.html">
                                                                    <img src="app-assets/images/portrait/small/avatar-s-3.jpg"
                                                                        class="me-75" height="50" width="50"
                                                                        alt="Angular" />
                                                                    <span class="fw-bold text-light">Blake Jhon</span>
                                                                </a>
                                                            </td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">TP-
                                                                    $25</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">FP-
                                                                    $10</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RT-
                                                                    $55</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">L-
                                                                    $35</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RV-
                                                                    $20</span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <a href="account.html">
                                                                    <img src="app-assets/images/portrait/small/avatar-s-7.jpg"
                                                                        class="me-75" height="50" width="50"
                                                                        alt="Angular" />
                                                                    <span class="fw-bold text-light">Smith Roy</span>
                                                                </a>
                                                            </td>
                                                            <td class="">
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">TP-
                                                                    $25</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">FP-
                                                                    $10</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RT-
                                                                    $55</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">L-
                                                                    $35</span>
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">RV-
                                                                    $20</span>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Content</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--/ Permission Table -->
                        <!-- Add Permission Modal -->
                        <div class="modal fade" id="addPermissionModal" tabindex="-1" style="display: none;"
                            aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-transparent">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body px-sm-5 pb-5">
                                        <div class="text-center mb-2">
                                            <h1 class="mb-1">Edit Content</h1>
                                        </div>
                                        <form id="addPermissionForm" class="row" onsubmit="return false"
                                            novalidate="novalidate">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="form-control-repeater">
                                                        <div class="">
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <form action="#" class="invoice-repeater">
                                                                        <div class="invoice-repeater">
                                                                            <div data-repeater-list="invoice">
                                                                                <div data-repeater-item>
                                                                                    <div
                                                                                        class="row d-flex align-items-end">
                                                                                        <div class="col-5">
                                                                                            <div class="mb-1">
                                                                                                <label
                                                                                                    class="form-label"
                                                                                                    for="select-content-name">Content
                                                                                                    Name</label>
                                                                                                <select
                                                                                                    class="form-select"
                                                                                                    id="select-content-name">
                                                                                                    <option
                                                                                                        value="DigiWallet">
                                                                                                        TP</option>
                                                                                                    <option
                                                                                                        value="Eezy Cash">
                                                                                                        L</option>
                                                                                                    <option
                                                                                                        value="Eezy Cash">
                                                                                                        RT</option>
                                                                                                    <option
                                                                                                        value="Eezy Cash">
                                                                                                        RV</option>
                                                                                                    <option
                                                                                                        value="Fast Cash">
                                                                                                        FP</option>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="col-5">
                                                                                            <div class="mb-1">
                                                                                                <label
                                                                                                    for="price">Price</label>
                                                                                                <div class="top-25"
                                                                                                    ondblclick="edit(this)">
                                                                                                    <input
                                                                                                        class="price-change"
                                                                                                        value="$15"
                                                                                                        id="price"
                                                                                                        disabled
                                                                                                        onblur="disable(this)">
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="col-2">
                                                                                            <div class="mb-1">
                                                                                                <button
                                                                                                    class="btn btn-outline-danger text-nowrap"
                                                                                                    data-repeater-delete
                                                                                                    type="button">
                                                                                                    <i data-feather="x"
                                                                                                        class="me-25"></i>
                                                                                                </button>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <hr />
                                                                                </div>
                                                                            </div>
                                                                            <div class="row">
                                                                                <div class="col-12">
                                                                                    <button
                                                                                        class="btn btn-icon btn-primary sign-log-btn"
                                                                                        type="button"
                                                                                        data-repeater-create>
                                                                                        <i data-feather="plus"
                                                                                            class="me-25"></i>
                                                                                        <span>Add New</span>
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 text-center">
                                                <button type="submit"
                                                    class="btn btn-primary mt-2 me-1 waves-effect waves-float waves-light">Add</button>
                                                <button type="reset" class="btn btn-outline-secondary mt-2 waves-effect"
                                                    data-bs-dismiss="modal" aria-label="Close">
                                                    Discard
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ Add Permission Modal -->
                        <!-- Edit Permission Modal -->
                        <div class="modal fade" id="editPermissionModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-transparent">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body p-3 pt-0">
                                        <div class="text-center mb-2">
                                            <h1 class="mb-1">Edit Social</h1>
                                        </div>

                                        <div class="alert alert-warning" role="alert">
                                            <h6 class="alert-heading">Warning!</h6>
                                            <div class="alert-body">
                                                By editing the permission name, you might break the system permissions
                                                functionality. Please ensure you're
                                                absolutely certain before proceeding.
                                            </div>
                                        </div>

                                        <form id="editPermissionForm" class="row" onsubmit="return false"
                                            novalidate="novalidate">
                                            <div class="col-sm-9">
                                                <label class="form-label" for="editPermissionName">Social Name</label>
                                                <input type="text" id="editPermissionName" name="editPermissionName"
                                                    class="form-control" placeholder="Enter a Social name" tabindex="-1"
                                                    data-msg="Please enter permission name">
                                            </div>
                                            <div class="col-sm-3 ps-sm-0">
                                                <button type="submit"
                                                    class="btn btn-primary mt-2 waves-effect waves-float waves-light">Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <!-- Select2 End -->
    </div>
</div>
<!-- END: Content-->
@endsection