@extends('layouts.app')

@section('content')
<!-- BEGIN: Content-->
<div class="content-overlay"></div>
<div class="header-navbar-shadow"></div>
<div class="content-wrapper container-xxl p-0">
    <div class="content-header row">
        @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
        @endif

        @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
        @endif
    </div>
    
    <div class="content-body">
        <!-- Select2 Start  -->
        <section id="multiple-column-form">
            <div class="row">
                <div class="col-12">
                    <form action="{{ route('approve_campaign2') }}" method="POST">
                    @csrf
                    <input type="hidden" name="campaign_id" value="{{ $campaign->id }}" />
                    <div class="card">
                        <div class="card-header">
                            <div class="col-12 col-md-6">
                                <h4 class="card-title">Campaign Name : <span class="text-success">{{ $campaign->campaign_name }}</span>
                                </h4>
                            </div>
                            <div class="col-12 col-md-6 text-md-end mt-1">
                                <p>Starting Date : <span class="text-success">{{ $campaign->starting_date }}</span></p>
                                <p>Ending Date : <span class="text-success">{{ $campaign->ending_date }}</span></p>
                            </div>
                        </div>
                        <hr>
                        @php
                        $client = DB::table('clients')->where('id', $campaign->client_id)->first();
                        @endphp
                        <div class="card-body">
                            <h4 class="pb-1">Client Name : <span class="text-warning">{{ $client->name }}</span></h4>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <div class="custom-bg">
                                        <ul class="list-unstyled">
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Budget:</span>
                                                <span>{{ $campaign->budget }}</span>
                                            </li>
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Paid Amount:</span>
                                                <span>N/A</span>
                                            </li>
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Budget Remaining:</span>
                                                <span>N/A</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="custom-bg">
                                        <ul class="list-unstyled">
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Region:</span>
                                                <span>Asia</span>
                                            </li>
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Campaign Goal:</span>
                                                <span>Reach 2k users</span>
                                            </li>
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Main call to Action:</span>
                                                <span><a href="">google/meet.com</a></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-3 pt-2">
                                <div class="col-12 col-md-6">
                                    <div class="custom-bg">
                                        <h4>Client Brif</h4>
                                        <p>{{ $campaign->client_brief }}</p>
                                        <ul class="list-unstyled">
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Asset:</span>
                                                <!--<a href=""><img src="images/drive.png" alt="" style="height: 20px; width: 20px;"></a>-->
                                                <p>{{ $campaign->asset }}</p>
                                            </li>
                                            <li class="mb-75">
                                                <span class="fw-bolder me-25">Client Brief Link:</span>
                                                <a href="">#</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="custom-bg">
                                        <h4>Influencer</h4>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Content</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                    $campaign_id = $campaign->id;
                                                    $influencers = DB::table('campaign_influencer')
                                                        ->where('campaign_id', $campaign_id)->get();
                                                    @endphp
                                                    
                                                    @foreach($influencers as $key=>$influencer)
                                                    
                                                        @php
                                                        $influencer_detail = DB::table('influencer')
                                                            ->where('id', $influencer->influencer_id)->first();
                                                            
                                                            
                                                        $twitter_detail = DB::table('influencer_socials')
                                                            ->where('influencer_id', $influencer_detail->id)
                                                            ->where('social_id', 6)
                                                            ->first();
                                                            
                                                        $twitter_profile_image_url = null;
                                                        if($twitter_detail){
                                                            $twitter_link= $twitter_detail->social_address;
                                                            $twitter_arr = explode('/', $twitter_link);
                                                            $twitter_arr = array_reverse($twitter_arr);
                                                            $twitter_username = $twitter_arr[0];
                                                            
                                                            if($twitter_username){
                                                                $curl = curl_init();
                
                                                                curl_setopt_array($curl, array(
                                                                  CURLOPT_URL => 'http://209.97.162.57/twitter?username='.$twitter_username,
                                                                  CURLOPT_RETURNTRANSFER => true,
                                                                  CURLOPT_ENCODING => '',
                                                                  CURLOPT_MAXREDIRS => 10,
                                                                  CURLOPT_TIMEOUT => 0,
                                                                  CURLOPT_FOLLOWLOCATION => true,
                                                                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                                                  CURLOPT_CUSTOMREQUEST => 'GET',
                                                                ));
                                                                
                                                                $response = curl_exec($curl);
                                                                
                                                                curl_close($curl);
                                                                $response = json_decode($response, true);
                                                                
                                                                if($response)
                                                                {
                                                                    $twitter_profile_image_url = $response['profile_image_url'];
                                                                }
                                                            }
                                                        }
                                                        
                                                        
                                                        $all_contents = DB::table('influencer_contents')
                                                            ->where('influencer_id', $influencer_detail->id)
                                                            ->join('contents', 'influencer_contents.content_id', '=', 'contents.id')
                                                            ->get();
                                                        @endphp
                                                        <tr>
                                                            <td>
                                                                <a href="#">
                                                                    <img src="{{ $twitter_profile_image_url }}"
                                                                        class="me-75" height="40" width="40"
                                                                        alt="Angular" />
                                                                    <span class="fw-bold text-light">{{ $influencer_detail->name }}</span>
                                                                </a>
                                                            </td>
                                                            <td class="">
                                                                @foreach($all_contents as $key=>$content)
                                                                <span
                                                                    class="badge rounded-pill badge-light-info link-bottom">{{$content->short_name}}-
                                                                    {{$content->price}}</span>
                                                                @endforeach
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if(Auth::user()->role == 'Client' && $campaign->status == 'Approved')
                                <input type="hidden" value="Ongoing" name="set_status" />
                                <input type="submit" class="btn btn-primary mt-1" value="Accept Campaign" />
                            @elseif(Auth::user()->role != 'Client' && $campaign->status == 'Pending')
                                <input type="hidden" value="Approved" name="set_status" />
                                <input type="submit" class="btn btn-primary mt-1" value="Approve Campaign" />
                            @endif
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </section>
        <!-- Select2 End -->
    </div>
</div>
<!-- END: Content-->

@endsection